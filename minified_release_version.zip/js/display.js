import{getComments as e}from"./fetcher.js";let userContainer=document.getElementById("user-container"),userInfoContainer=document.getElementById("userinfo-container"),postContainer=document.getElementById("post-container"),todoContainer=document.getElementById("todo-container"),modal=document.querySelector(".modal"),overlay=document.querySelector(".overlay");export const toggleModal=()=>{modal.classList.toggle("hidden"),overlay.classList.toggle("hidden"),todoContainer.innerHTML="",postContainer.innerHTML="",userInfoContainer.innerHTML=""};export const showSpinners=()=>{[userInfoContainer,postContainer,todoContainer].forEach(e=>{e.innerHTML='<i class="fa-solid fa-gear spinner"></i>'})};export const showUsers=function(e){userContainer.innerHTML="",e.forEach(e=>{let t=document.createElement("article");t.classList.add("user-card"),t.dataset.userId=e.id,t.innerHTML=`
  <img src="./img/default-avatar.webp" class="avatar" alt="avatar">
  <h2>${e.name}</h2>
  <p>Email: ${e.email}</p>
  `,userContainer.append(t)})};export const showTodos=function(e){todoContainer.innerHTML="",e.forEach(e=>{let t=document.createElement("div");t.classList.add("todo-item"),todoContainer.appendChild(t);let n=document.createElement("label");n.htmlFor=`todo-${e.id}`,n.textContent=e.title;let o=document.createElement("input");o.setAttribute("type","checkbox"),o.id=`todo-${e.id}`,!0===e.completed&&(o.checked=!0),t.append(n),t.append(o)})};export const showPosts=async function(t){let n=await e(t);postContainer.innerHTML="",t.forEach(e=>{let t=document.createElement("article");t.classList.add("post-card"),t.innerHTML=`
    <h3>${e.title}</h3>
    <p>${e.body}</p>
    <h3>Kommentarer</h3>
    `;let o=n.filter(t=>t.postId===e.id),r=o.slice(0,3),a=document.createElement("div");a.classList.add("comments-container"),r.forEach(e=>{let t=document.createElement("p");t.classList.add("comment"),t.textContent=e.body,a.appendChild(t)}),t.append(a),postContainer.append(t)})};export const showUserInfo=function(e){userInfoContainer.innerHTML="";let t=document.createElement("div");t.classList.add("user-info"),t.innerHTML=`
      <h3>${e.name}</h3>
      <p><strong>Anv\xe4ndarnamn:</strong> ${e.username}</p>
      <p><strong>Email:</strong> ${e.email}</p>
      <p><strong>Telefon:</strong> ${e.phone}</p>
      <p><strong>Hemsida:</strong> <a href="https://${e.website}" target="_blank">${e.website}</a></p>
      <p><strong>F\xf6retag:</strong> ${e.company.name}</p>
      <p><strong>Adress:</strong> ${e.address.street}, ${e.address.suite}, ${e.address.city}</p>
      `,userInfoContainer.append(t)};
